﻿namespace $ext_safeprojectname$.WPF.Views.Windows
{
    /// <summary>   Second window of project. </summary>
    public partial class SecondWindow
    {
        /// <summary>   Default constructor. </summary>
        public SecondWindow()
        {
            InitializeComponent();
        }
    }
}