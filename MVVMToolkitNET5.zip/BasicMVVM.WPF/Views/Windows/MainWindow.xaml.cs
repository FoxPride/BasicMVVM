﻿namespace $ext_safeprojectname$.WPF.Views.Windows
{
    /// <summary>   The application's main window. </summary>
    public partial class MainWindow
    {
        /// <summary>   Default constructor. </summary>
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}