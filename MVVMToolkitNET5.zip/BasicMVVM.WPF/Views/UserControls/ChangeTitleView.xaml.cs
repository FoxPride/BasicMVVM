﻿namespace $ext_safeprojectname$.WPF.Views.UserControls
{
    /// <summary>   A change title view. </summary>
    public partial class ChangeTitleView
    {
        /// <summary>   Default constructor. </summary>
        public ChangeTitleView()
        {
            InitializeComponent();
        }
    }
}