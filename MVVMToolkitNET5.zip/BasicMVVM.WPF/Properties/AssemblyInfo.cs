﻿using System.Reflection;

[assembly: AssemblyMetadata("SquirrelAwareVersion", "1")]