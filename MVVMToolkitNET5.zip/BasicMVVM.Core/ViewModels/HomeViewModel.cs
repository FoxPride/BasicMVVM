﻿using Microsoft.Toolkit.Mvvm.ComponentModel;

namespace $ext_safeprojectname$.Core.ViewModels
{
    /// <summary>   A ViewModel for the home view. </summary>
    public class HomeViewModel : ObservableObject
    {
    }
}