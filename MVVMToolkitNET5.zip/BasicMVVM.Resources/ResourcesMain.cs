﻿namespace $ext_safeprojectname$.Resources
{
    /// <summary>   A helper <see langword="class" /> for UI language setup. </summary>
    public class ResourcesMain
    {
    }
}