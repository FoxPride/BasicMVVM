﻿namespace WpfTest
{
    /// <summary>   The main window of test project. </summary>
    public partial class MainWindow
    {
        /// <summary>   Initializes a new instance of the <see cref="MainWindow"/> class. </summary>
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}