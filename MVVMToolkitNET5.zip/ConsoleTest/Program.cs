﻿using System;

namespace ConsoleTest
{
    /// <summary>   Console project for tests. </summary>
    internal static class Program
    {
        ////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>   Entry point of console app. </summary>
        ///
        /// <param name="args"> The startup args. </param>
        ////////////////////////////////////////////////////////////////////////////////////////////////////
        private static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}